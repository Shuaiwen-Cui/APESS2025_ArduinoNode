#pragma once

#include "config.hpp"

// Function declaration
void connect_to_wifi();
